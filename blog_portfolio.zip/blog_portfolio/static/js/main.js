// main.js - Fonctionnalités JavaScript pour le site Blog & Portfolio

document.addEventListener('DOMContentLoaded', function() {
    // Animation des éléments au défilement
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.card, .progress, h1, h2, h3');
        
        elements.forEach(element => {
            const position = element.getBoundingClientRect();
            
            // Si l'élément est visible dans la fenêtre
            if(position.top < window.innerHeight && position.bottom >= 0) {
                element.classList.add('fade-in');
            }
        });
    };
    
    // Exécuter l'animation au chargement et au défilement
    animateOnScroll();
    window.addEventListener('scroll', animateOnScroll);
    
    // Validation du formulaire de commentaire
    const commentForm = document.querySelector('form[action="#"]');
    if (commentForm) {
        commentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const body = document.getElementById('body').value.trim();
            
            if (name === '' || email === '' || body === '') {
                alert('Veuillez remplir tous les champs du formulaire.');
                return;
            }
            
            // Simulation d'envoi de commentaire (à remplacer par un vrai traitement AJAX)
            const commentSection = document.querySelector('.card-body');
            const newComment = document.createElement('div');
            newComment.className = 'alert alert-success';
            newComment.innerHTML = `<p>Merci pour votre commentaire, ${name}!</p>
                                   <p>Votre commentaire a été soumis et sera publié après modération.</p>`;
            
            commentForm.reset();
            commentForm.parentNode.insertBefore(newComment, commentForm);
            
            // Cacher le formulaire après 3 secondes
            setTimeout(() => {
                commentForm.style.display = 'none';
            }, 3000);
        });
    }
    
    // Filtrage des projets par catégorie
    const filterButtons = document.querySelectorAll('.btn-group .btn-outline-primary');
    if (filterButtons.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Mise à jour de la classe active
                filterButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }
    
    // Effet de survol sur les cartes de projet
    const projectCards = document.querySelectorAll('.card');
    projectCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
            this.style.boxShadow = '0 10px 20px rgba(0, 0, 0, 0.2)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
        });
    });
    
    // Bouton retour en haut de page
    const createBackToTopButton = function() {
        const button = document.createElement('button');
        button.innerHTML = '<i class="fas fa-arrow-up"></i>';
        button.className = 'back-to-top';
        button.style.position = 'fixed';
        button.style.bottom = '20px';
        button.style.right = '20px';
        button.style.display = 'none';
        button.style.padding = '10px 15px';
        button.style.backgroundColor = 'var(--primary-color)';
        button.style.color = 'white';
        button.style.border = 'none';
        button.style.borderRadius = '50%';
        button.style.cursor = 'pointer';
        button.style.zIndex = '1000';
        button.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.3)';
        
        document.body.appendChild(button);
        
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                button.style.display = 'block';
            } else {
                button.style.display = 'none';
            }
        });
        
        button.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    };
    
    createBackToTopButton();
});
