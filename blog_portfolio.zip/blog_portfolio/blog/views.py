from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .models import Post, Category

def post_list(request, category_slug=None):
    category = None
    posts = Post.objects.filter(status='published')
    
    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        posts = posts.filter(categories=category)
    
    # Pagination avec 5 articles par page
    paginator = Paginator(posts, 5)
    page = request.GET.get('page')
    
    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        # Si la page n'est pas un entier, afficher la première page
        posts = paginator.page(1)
    except EmptyPage:
        # Si la page est hors limites, afficher la dernière page
        posts = paginator.page(paginator.num_pages)
    
    return render(request, 'blog/post/list.html', {
        'posts': posts,
        'category': category,
        'page': page,
    })

def post_detail(request, year, month, day, post):
    post = get_object_or_404(Post, 
                            slug=post,
                            status='published',
                            publish__year=year,
                            publish__month=month,
                            publish__day=day)
    
    # Liste des commentaires actifs pour cet article
    comments = post.comments.filter(active=True)
    
    return render(request, 'blog/post/detail.html', {
        'post': post,
        'comments': comments,
    })

def about(request):
    return render(request, 'blog/about.html')
