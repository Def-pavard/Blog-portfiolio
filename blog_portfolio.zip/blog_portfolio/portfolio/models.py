from django.db import models
from django.urls import reverse

class Project(models.Model):
    CATEGORY_CHOICES = (
        ('web', 'Développement Web'),
        ('mobile', 'Développement Mobile'),
        ('design', 'Design'),
        ('other', 'Autre'),
    )
    
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True)
    description = models.TextField()
    image = models.ImageField(upload_to='portfolio/projects/')
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='web')
    client = models.CharField(max_length=100, blank=True)
    completed_date = models.DateField()
    url = models.URLField(blank=True)
    featured = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-completed_date']
    
    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse('portfolio:project_detail', args=[self.slug])

class Skill(models.Model):
    SKILL_TYPE_CHOICES = (
        ('technical', 'Compétence Technique'),
        ('soft', 'Soft Skill'),
        ('language', 'Langue'),
    )
    
    name = models.CharField(max_length=100)
    skill_type = models.CharField(max_length=20, choices=SKILL_TYPE_CHOICES, default='technical')
    level = models.IntegerField(choices=[(i, i) for i in range(1, 6)], default=3)  # 1-5 scale
    
    def __str__(self):
        return self.name
