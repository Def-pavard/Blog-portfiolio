from django.shortcuts import render, get_object_or_404
from .models import Project, Skill

def project_list(request, category=None):
    projects = Project.objects.all()
    
    if category:
        projects = projects.filter(category=category)
    
    featured_projects = projects.filter(featured=True)[:3]
    
    return render(request, 'portfolio/project/list.html', {
        'projects': projects,
        'featured_projects': featured_projects,
        'category': category,
    })

def project_detail(request, slug):
    project = get_object_or_404(Project, slug=slug)
    
    return render(request, 'portfolio/project/detail.html', {
        'project': project,
    })

def skill_list(request):
    technical_skills = Skill.objects.filter(skill_type='technical')
    soft_skills = Skill.objects.filter(skill_type='soft')
    languages = Skill.objects.filter(skill_type='language')
    
    return render(request, 'portfolio/skill/list.html', {
        'technical_skills': technical_skills,
        'soft_skills': soft_skills,
        'languages': languages,
    })

def home(request):
    featured_projects = Project.objects.filter(featured=True)[:3]
    latest_projects = Project.objects.all()[:4]
    
    return render(request, 'portfolio/home.html', {
        'featured_projects': featured_projects,
        'latest_projects': latest_projects,
    })
