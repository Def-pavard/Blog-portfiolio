# Custom template filter for multiply
