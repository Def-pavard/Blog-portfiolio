from django.contrib import admin
from .models import Project, Skill

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ['title', 'slug', 'category', 'completed_date', 'featured']
    list_filter = ['category', 'featured', 'completed_date']
    search_fields = ['title', 'description', 'client']
    prepopulated_fields = {'slug': ('title',)}
    date_hierarchy = 'completed_date'
    ordering = ['-completed_date']

@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    list_display = ['name', 'skill_type', 'level']
    list_filter = ['skill_type', 'level']
    search_fields = ['name']
    ordering = ['skill_type', '-level']
